weblogic Cookbook CHANGELOG
========================
v2.1.5
Fix group membership #19

v2.1.4
Fix silent file owner #17

v2.1.3
Add weblogic 10.3.5
Changes teste CentOS version to 6.7

v2.1.2 (2015-12-15)
Add weblogic 12.2.1

v2.1.0 (2015-11-20)
Deprecate v2.1.1 as per issue #10

v2.1.0 (2015-11-20)
Move to custom resources

v2.0.2 (2015-07-16)
Fix Berkshelf to point to the new supermarket universe endpoint (@smford22)

v2.0.1 (2015-05-27)
Fixed issue #3: removed reference to old cookbook name.  Weblogic 12.1.1/12.1.2 tests working.

v2.0.0 (2015-05-21)
Bumped version to work around conflict.

v1.0.0 (2015-05-14)
Added waffle.io badge.

v0.1.1 (2015-05-10)
Initial release.

This now uses the resource cookbook which is currently under active development.
https://github.com/chef-cookbooks/resource
